# Console-Based Car Rental Service

## Project Overview
This project implements a simple, console-driven application for managing a car rental service. It allows for the management of vehicles, customer information, and rental transactions. All data is stored in memory and is not persistent; it will be lost upon program termination.

This system demonstrates key concepts in object-oriented programming (OOP), data structures (Java Collections), basic console I/O, and robust error handling. It is designed to be a clear and functional example of a command-line application, meeting standard software project review criteria.

## Features Implemented

The Car Rental Service provides the following core functionalities:

* **Vehicle Management:**
    * Add new vehicles (with unique VIN, Make, Model, Year, Daily Rental Rate, and initial availability).
    * Display a list of all vehicles in the fleet.
    * Display only currently available vehicles.
    * Search for vehicles by Make, Model, or VIN.
* **Customer Management:**
    * Register new customers (with unique Customer ID, Name, Contact Information, and Driver's License Number).
    * Display a list of all registered customers.
    * Search for customers by Customer ID or Name.
* **Rental Management:**
    * **Rent a Car:** Process new rental agreements, assigning an available vehicle to a registered customer for a specified period.
    * **Return a Car:** Handle vehicle returns, calculate the total rental cost based on actual duration, and update vehicle availability.
    * View all currently active rental agreements.
    * View the complete rental history for a specific customer.
* **Robustness & Validation:**
    * Comprehensive input validation for all user inputs (e.g., non-empty fields, valid contact numbers, VIN/License formats, valid dates, positive rates).
    * Error handling for invalid operations (e.g., attempting to rent an unavailable car, returning an un-rented car, non-existent IDs, illogical dates).
    * Prevention of duplicate Vehicle VINs, Customer IDs, and Driver's License Numbers.

## Project Structure

The project follows a modular and organized package structure: