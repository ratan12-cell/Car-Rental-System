package com.example.rental.service;

import com.example.rental.model.Vehicle;
import com.example.rental.model.Customer;
import com.example.rental.model.Rental;
import com.example.rental.model.VehicleStatus;
import com.example.rental.util.Validator;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RentalService {
    private List<Vehicle> vehicles;
    private List<Customer> customers;
    private List<Rental> rentals;
    private static int rentalIdCounter = 1;

    public RentalService() {
        this.vehicles = new ArrayList<>();
        this.customers = new ArrayList<>();
        this.rentals = new ArrayList<>();
        seedData();
    }

    private void seedData() {
        addVehicle("VIN001", "Toyota", "Camry", 2020, 50.00);
        addVehicle("VIN002", "Honda", "Civic", 2022, 45.00);
        addVehicle("VIN003", "Ford", "F-150", 2019, 70.00);

        addCustomer("CUST001", "Alice Wonderland", "9876543210", "DL12345");
        addCustomer("CUST002", "Bob The Builder", "0123456789", "DL67890");

        // Pre-rent a car for demonstration
        rentCar("CUST001", "VIN001", LocalDate.now().minusDays(2), LocalDate.now().plusDays(3));
    }

    public void addVehicle(String vin, String make, String model, int year, double dailyRentalRate) {
        if (!Validator.isNotNullOrEmpty(vin) || !Validator.isNotNullOrEmpty(make) || !Validator.isNotNullOrEmpty(model)) {
            System.out.println("Error: VIN, Make, and Model cannot be empty.");
            return;
        }
        if (!Validator.isValidVin(vin)) {
            System.out.println("Error: Invalid VIN format (e.g., must be 6-10 alphanumeric characters).");
            return;
        }
        if (getVehicleByVin(vin) != null) {
            System.out.println("Error: Vehicle with VIN '" + vin + "' already exists.");
            return;
        }
        if (!Validator.isPositive(dailyRentalRate)) {
            System.out.println("Error: Daily rental rate must be a positive number.");
            return;
        }
        if (year < 1900 || year > LocalDate.now().getYear() + 1) { // Basic year validation
            System.out.println("Error: Invalid year. Please enter a realistic year.");
            return;
        }

        vehicles.add(new Vehicle(vin, make, model, year, dailyRentalRate));
        System.out.println("Vehicle '" + make + " " + model + "' (VIN: " + vin + ") added successfully.");
    }

    public void addCustomer(String customerId, String name, String contactNumber, String driversLicenseNumber) {
        if (!Validator.isNotNullOrEmpty(customerId) || !Validator.isNotNullOrEmpty(name) ||
            !Validator.isNotNullOrEmpty(contactNumber) || !Validator.isNotNullOrEmpty(driversLicenseNumber)) {
            System.out.println("Error: All customer fields must be provided.");
            return;
        }
        if (!Validator.isValidContactNumber(contactNumber)) {
            System.out.println("Error: Invalid contact number format.");
            return;
        }
        if (!Validator.isValidDriversLicense(driversLicenseNumber)) {
            System.out.println("Error: Invalid Driver's License format (e.g., 5-15 alphanumeric characters).");
            return;
        }
        if (getCustomerById(customerId) != null) {
            System.out.println("Error: Customer with ID '" + customerId + "' already exists.");
            return;
        }
        if (getCustomerByDriversLicense(driversLicenseNumber) != null) {
            System.out.println("Error: Customer with this Driver's License already registered.");
            return;
        }

        customers.add(new Customer(customerId, name, contactNumber, driversLicenseNumber));
        System.out.println("Customer '" + name + "' (ID: " + customerId + ") registered successfully.");
    }

    public void rentCar(String customerId, String vin, LocalDate rentalStartDate, LocalDate estimatedReturnDate) {
        Customer customer = getCustomerById(customerId);
        Vehicle vehicle = getVehicleByVin(vin);

        if (customer == null) {
            System.out.println("Error: Customer with ID '" + customerId + "' not found.");
            return;
        }
        if (vehicle == null) {
            System.out.println("Error: Vehicle with VIN '" + vin + "' not found.");
            return;
        }
        if (vehicle.getStatus() != VehicleStatus.AVAILABLE) {
            System.out.println("Error: Vehicle '" + vin + "' is not AVAILABLE. Current status: " + vehicle.getStatus());
            return;
        }
        if (!Validator.isValidRentalDates(rentalStartDate, estimatedReturnDate)) {
            System.out.println("Error: Invalid rental dates. Start date must be today or future, and estimated return must be after start date.");
            return;
        }

        String rentalId = "RENT" + String.format("%03d", rentalIdCounter++);
        Rental newRental = new Rental(rentalId, vehicle, customer, rentalStartDate, estimatedReturnDate);
        rentals.add(newRental);
        vehicle.setStatus(VehicleStatus.RENTED);
        System.out.println("Car '" + vehicle.getMake() + " " + vehicle.getModel() + "' (VIN: " + vin +
                           ") rented by '" + customer.getName() + "' (ID: " + customerId + "). Rental ID: " + rentalId);
    }

    public void returnCar(String vin, LocalDate actualReturnDate) {
        Vehicle vehicle = getVehicleByVin(vin);
        if (vehicle == null) {
            System.out.println("Error: Vehicle with VIN '" + vin + "' not found.");
            return;
        }
        if (vehicle.getStatus() != VehicleStatus.RENTED) {
            System.out.println("Error: Vehicle '" + vin + "' is not currently RENTED. Current status: " + vehicle.getStatus());
            return;
        }

        Rental activeRental = rentals.stream()
                                    .filter(r -> r.getRentedVehicle().getVin().equalsIgnoreCase(vin) && r.isActive())
                                    .findFirst()
                                    .orElse(null);

        if (activeRental == null) {
            System.out.println("Error: No active rental found for vehicle VIN '" + vin + "'.");
            return;
        }

        if (actualReturnDate.isBefore(activeRental.getRentalStartDate())) {
            System.out.println("Error: Actual return date cannot be before the rental start date.");
            return;
        }

        activeRental.setActualReturnDate(actualReturnDate);
        activeRental.setActive(false);
        vehicle.setStatus(VehicleStatus.AVAILABLE);
        System.out.println("Vehicle '" + vehicle.getMake() + " " + vehicle.getModel() + "' (VIN: " + vin +
                           ") returned successfully. Total cost: $" + String.format("%.2f", activeRental.getTotalCost()));
    }

    public Vehicle getVehicleByVin(String vin) {
        return vehicles.stream()
                       .filter(v -> v.getVin().equalsIgnoreCase(vin))
                       .findFirst()
                       .orElse(null);
    }

    public Customer getCustomerById(String customerId) {
        return customers.stream()
                        .filter(c -> c.getCustomerId().equalsIgnoreCase(customerId))
                        .findFirst()
                        .orElse(null);
    }

    public Customer getCustomerByDriversLicense(String driversLicense) {
        return customers.stream()
                        .filter(c -> c.getDriversLicenseNumber().equalsIgnoreCase(driversLicense))
                        .findFirst()
                        .orElse(null);
    }

    public void displayAllVehicles() {
        if (vehicles.isEmpty()) {
            System.out.println("No vehicles in the fleet.");
            return;
        }
        System.out.println("\n--- All Vehicles ---");
        vehicles.forEach(System.out::println);
        System.out.println("--------------------");
    }

    public void displayAvailableVehicles() {
        List<Vehicle> available = vehicles.stream()
                                          .filter(v -> v.getStatus() == VehicleStatus.AVAILABLE)
                                          .collect(Collectors.toList());
        if (available.isEmpty()) {
            System.out.println("No vehicles currently available.");
            return;
        }
        System.out.println("\n--- Available Vehicles ---");
        available.forEach(System.out::println);
        System.out.println("--------------------------");
    }

    public void searchVehicle(String query) {
        if (!Validator.isNotNullOrEmpty(query)) {
            System.out.println("Error: Search query cannot be empty.");
            return;
        }
        List<Vehicle> foundVehicles = vehicles.stream()
                                              .filter(v -> v.getMake().toLowerCase().contains(query.toLowerCase()) ||
                                                           v.getModel().toLowerCase().contains(query.toLowerCase()) ||
                                                           v.getVin().equalsIgnoreCase(query))
                                              .collect(Collectors.toList());
        if (foundVehicles.isEmpty()) {
            System.out.println("No vehicles found matching '" + query + "'.");
            return;
        }
        System.out.println("\n--- Search Results for '" + query + "' ---");
        foundVehicles.forEach(System.out::println);
        System.out.println("----------------------------------------");
    }

    public void displayAllCustomers() {
        if (customers.isEmpty()) {
            System.out.println("No customers registered.");
            return;
        }
        System.out.println("\n--- All Customers ---");
        customers.forEach(System.out::println);
        System.out.println("---------------------");
    }

    public void searchCustomer(String query) {
        if (!Validator.isNotNullOrEmpty(query)) {
            System.out.println("Error: Search query cannot be empty.");
            return;
        }
        List<Customer> foundCustomers = customers.stream()
                                                  .filter(c -> c.getName().toLowerCase().contains(query.toLowerCase()) ||
                                                               c.getCustomerId().equalsIgnoreCase(query))
                                                  .collect(Collectors.toList());
        if (foundCustomers.isEmpty()) {
            System.out.println("No customers found matching '" + query + "'.");
            return;
        }
        System.out.println("\n--- Search Results for '" + query + "' ---");
        foundCustomers.forEach(System.out::println);
        System.out.println("------------------------------------------");
    }

    public void displayAllActiveRentals() {
        List<Rental> activeRentals = rentals.stream()
                                            .filter(Rental::isActive)
                                            .collect(Collectors.toList());
        if (activeRentals.isEmpty()) {
            System.out.println("No active rentals found.");
            return;
        }
        System.out.println("\n--- Active Rentals ---");
        activeRentals.forEach(System.out::println);
        System.out.println("----------------------");
    }

    public void displayCustomerRentalHistory(String customerId) {
        Customer customer = getCustomerById(customerId);
        if (customer == null) {
            System.out.println("Error: Customer with ID '" + customerId + "' not found.");
            return;
        }

        List<Rental> customerRentals = rentals.stream()
                                              .filter(r -> r.getRentingCustomer().getCustomerId().equalsIgnoreCase(customerId))
                                              .collect(Collectors.toList());
        if (customerRentals.isEmpty()) {
            System.out.println("No rental history found for customer '" + customer.getName() + "'.");
            return;
        }
        System.out.println("\n--- Rental History for " + customer.getName() + " ---");
        customerRentals.forEach(System.out::println);
        System.out.println("---------------------------------------");
    }
}