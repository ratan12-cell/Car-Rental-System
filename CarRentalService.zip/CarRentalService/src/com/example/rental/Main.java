package com.example.rental;

import com.example.rental.service.RentalService;
import com.example.rental.util.InputHandler;

import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InputHandler inputHandler = new InputHandler(scanner);
        RentalService rentalService = new RentalService();

        System.out.println("Welcome to the Console Car Rental Service!");

        while (true) {
            displayMenu();
            int choice = inputHandler.getIntegerInput("Enter your choice: ");

            switch (choice) {
                case 1: // Add Vehicle
                    String vin = inputHandler.getStringInput("Enter Vehicle VIN: ");
                    String make = inputHandler.getStringInput("Enter Make: ");
                    String model = inputHandler.getStringInput("Enter Model: ");
                    int year = inputHandler.getIntegerInput("Enter Year: ");
                    double dailyRate = inputHandler.getDoubleInput("Enter Daily Rental Rate: ");
                    rentalService.addVehicle(vin, make, model, year, dailyRate);
                    break;
                case 2: // Add Customer
                    String customerId = inputHandler.getStringInput("Enter Customer ID: ");
                    String name = inputHandler.getStringInput("Enter Customer Name: ");
                    String contact = inputHandler.getStringInput("Enter Contact Number: ");
                    String license = inputHandler.getStringInput("Enter Driver's License Number: ");
                    rentalService.addCustomer(customerId, name, contact, license);
                    break;
                case 3: // Rent Car
                    String rentCustId = inputHandler.getStringInput("Enter Customer ID: ");
                    String rentVin = inputHandler.getStringInput("Enter Vehicle VIN: ");
                    LocalDate startDate = inputHandler.getDateInput("Enter Rental Start Date");
                    LocalDate estimatedReturnDate = inputHandler.getDateInput("Enter Estimated Return Date");
                    rentalService.rentCar(rentCustId, rentVin, startDate, estimatedReturnDate);
                    break;
                case 4: // Return Car
                    String returnVin = inputHandler.getStringInput("Enter VIN of Vehicle to return: ");
                    LocalDate actualReturnDate = inputHandler.getDateInput("Enter Actual Return Date");
                    rentalService.returnCar(returnVin, actualReturnDate);
                    break;
                case 5: // Display All Vehicles
                    rentalService.displayAllVehicles();
                    break;
                case 6: // Display Available Vehicles
                    rentalService.displayAvailableVehicles();
                    break;
                case 7: // Search Vehicle
                    String vehicleQuery = inputHandler.getStringInput("Enter Vehicle Make, Model, or VIN to search: ");
                    rentalService.searchVehicle(vehicleQuery);
                    break;
                case 8: // Display All Customers
                    rentalService.displayAllCustomers();
                    break;
                case 9: // Search Customer
                    String customerQuery = inputHandler.getStringInput("Enter Customer ID or Name to search: ");
                    rentalService.searchCustomer(customerQuery);
                    break;
                case 10: // Display All Active Rentals
                    rentalService.displayAllActiveRentals();
                    break;
                case 11: // Display Customer Rental History
                    String historyCustId = inputHandler.getStringInput("Enter Customer ID to view rental history: ");
                    rentalService.displayCustomerRentalHistory(historyCustId);
                    break;
                case 0:
                    System.out.println("Exiting Car Rental Service. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println("\nPress Enter to continue...");
            inputHandler.getStringInput("");
        }
    }

    private static void displayMenu() {
        System.out.println("\n--- Car Rental Menu ---");
        System.out.println("1. Add New Vehicle");
        System.out.println("2. Add New Customer");
        System.out.println("3. Rent a Car");
        System.out.println("4. Return a Car");
        System.out.println("5. Display All Vehicles");
        System.out.println("6. Display Available Vehicles");
        System.out.println("7. Search Vehicle");
        System.out.println("8. Display All Customers");
        System.out.println("9. Search Customer");
        System.out.println("10. Display All Active Rentals");
        System.out.println("11. Display Customer Rental History");
        System.out.println("0. Exit");
        System.out.println("-----------------------");
    }
}