package com.example.rental.util;

import java.time.LocalDate;

public class Validator {

    public static boolean isNotNullOrEmpty(String str) {
        return str != null && !str.trim().isEmpty();
    }

    public static boolean isPositive(double number) {
        return number > 0;
    }

    public static boolean isValidContactNumber(String contact) {
        if (!isNotNullOrEmpty(contact)) {
            return false;
        }
        // Simple validation: 10-15 digits, optional hyphens or spaces
        return contact.matches("^[0-9\\-\\s]{10,15}$");
    }

    public static boolean isValidVin(String vin) {
        if (!isNotNullOrEmpty(vin)) {
            return false;
        }
        // Simple validation: alphanumeric, 6 to 10 characters
        return vin.matches("^[a-zA-Z0-9]{6,10}$");
    }

    public static boolean isValidDriversLicense(String license) {
        if (!isNotNullOrEmpty(license)) {
            return false;
        }
        // Simple validation: alphanumeric, 5 to 15 characters
        return license.matches("^[a-zA-Z0-9]{5,15}$");
    }

    public static boolean isValidRentalDates(LocalDate startDate, LocalDate endDate) {
        if (startDate == null || endDate == null) {
            return false;
        }
        // Start date must be today or in the future
        if (startDate.isBefore(LocalDate.now())) {
            return false;
        }
        // End date must be after start date
        if (endDate.isBefore(startDate) || endDate.isEqual(startDate)) {
            return false;
        }
        return true;
    }
}