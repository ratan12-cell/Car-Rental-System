package com.example.rental.model;

public class Customer {
    private String customerId;
    private String name;
    private String contactNumber;
    private String driversLicenseNumber;

    public Customer(String customerId, String name, String contactNumber, String driversLicenseNumber) {
        this.customerId = customerId;
        this.name = name;
        this.contactNumber = contactNumber;
        this.driversLicenseNumber = driversLicenseNumber;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public String getDriversLicenseNumber() {
        return driversLicenseNumber;
    }

    @Override
    public String toString() {
        return "Customer ID: " + customerId + ", Name: " + name +
               ", Contact: " + contactNumber + ", License: " + driversLicenseNumber;
    }
}