package com.example.rental.model;

public class Vehicle {
    private String vin;
    private String make;
    private String model;
    private int year;
    private double dailyRentalRate;
    private VehicleStatus status;

    public Vehicle(String vin, String make, String model, int year, double dailyRentalRate) {
        this.vin = vin;
        this.make = make;
        this.model = model;
        this.year = year;
        this.dailyRentalRate = dailyRentalRate;
        this.status = VehicleStatus.AVAILABLE;
    }

    public String getVin() {
        return vin;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public double getDailyRentalRate() {
        return dailyRentalRate;
    }

    public VehicleStatus getStatus() {
        return status;
    }

    public void setStatus(VehicleStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "VIN: " + vin + ", Make: " + make + ", Model: " + model +
               ", Year: " + year + ", Rate: $" + String.format("%.2f", dailyRentalRate) + "/day, Status: " + status;
    }
}