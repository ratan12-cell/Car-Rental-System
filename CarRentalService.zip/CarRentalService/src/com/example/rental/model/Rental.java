package com.example.rental.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Rental {
    private String rentalId;
    private Vehicle rentedVehicle;
    private Customer rentingCustomer;
    private LocalDate rentalStartDate;
    private LocalDate estimatedReturnDate;
    private LocalDate actualReturnDate;
    private double totalCost;
    private boolean isActive;

    public Rental(String rentalId, Vehicle rentedVehicle, Customer rentingCustomer, LocalDate rentalStartDate, LocalDate estimatedReturnDate) {
        this.rentalId = rentalId;
        this.rentedVehicle = rentedVehicle;
        this.rentingCustomer = rentingCustomer;
        this.rentalStartDate = rentalStartDate;
        this.estimatedReturnDate = estimatedReturnDate;
        this.actualReturnDate = null;
        this.totalCost = 0.0;
        this.isActive = true;
    }

    public String getRentalId() {
        return rentalId;
    }

    public Vehicle getRentedVehicle() {
        return rentedVehicle;
    }

    public Customer getRentingCustomer() {
        return rentingCustomer;
    }

    public LocalDate getRentalStartDate() {
        return rentalStartDate;
    }

    public LocalDate getEstimatedReturnDate() {
        return estimatedReturnDate;
    }

    public LocalDate getActualReturnDate() {
        return actualReturnDate;
    }

    public void setActualReturnDate(LocalDate actualReturnDate) {
        this.actualReturnDate = actualReturnDate;
        calculateTotalCost();
    }

    public double getTotalCost() {
        return totalCost;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    private void calculateTotalCost() {
        if (actualReturnDate != null && rentedVehicle != null) {
            long days = ChronoUnit.DAYS.between(rentalStartDate, actualReturnDate);
            if (days < 0) { // If actual return is before start date, should not happen but for safety
                days = 0;
            } else if (days == 0) { // If returned on the same day, count as 1 day
                 days = 1;
            }
            this.totalCost = days * rentedVehicle.getDailyRentalRate();
        }
    }

    @Override
    public String toString() {
        String actualReturn = (actualReturnDate != null) ? ", Actual Return: " + actualReturnDate : "";
        String costInfo = (totalCost > 0) ? ", Cost: $" + String.format("%.2f", totalCost) : "";
        return "Rental ID: " + rentalId +
               "\n  Vehicle: [" + rentedVehicle.getMake() + " " + rentedVehicle.getModel() + " (" + rentedVehicle.getVin() + ")]" +
               "\n  Customer: " + rentingCustomer.getName() + " (" + rentingCustomer.getCustomerId() + ")" +
               "\n  Period: " + rentalStartDate + " to " + estimatedReturnDate + actualReturn +
               "\n  Status: " + (isActive ? "Active" : "Completed") + costInfo;
    }
}