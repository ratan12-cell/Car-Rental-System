package com.example.rental.model;

public enum VehicleStatus {
    AVAILABLE,
    RENTED,
    MAINTENANCE
}