Car Rental System
This is a simple Car Rental System application built using Java Swing. It provides an intuitive graphical user interface (GUI) to manage car rentals, track customer details, and monitor fleet statistics.

Features
Car Management: Easily add new cars to your fleet, specifying their ID, brand, model, and base price per day.
Rent a Car: Facilitates the rental process for available cars, capturing customer information and rental duration.
Return a Car: Allows you to mark rented cars as returned, making them available for future rentals.
Rental History: View a comprehensive list of all rental transactions, clearly indicating whether a rental is active or returned.
Search & Filter: Quickly find specific rentals by searching for car ID, customer name, or phone number. You can also filter the rental list by status (active, returned) or by rental date (last 7 days, last 30 days).
Real-time Statistics: Get instant updates on key metrics like total cars, available cars, rented cars, and the count of active and returned rentals.
Rental Receipt: Generates a detailed receipt for each new rental transaction.
User-Friendly GUI: Features a clean and easy-to-navigate interface for a smooth user experience.
How to Run
To get this Car Rental System up and running on your local machine, follow these steps:

Save the Code:

Save the entire provided Java code into a single file named CarRentalSystem.java. Ensure all inner classes (like Car, Customer, Rental, CarListRenderer, RentalListRenderer) are included within this file.
Compile the Code:

Open your terminal or command prompt.
Navigate to the directory where you saved CarRentalSystem.java.
Compile the Java code using the javac command:
Bash

javac CarRentalSystem.java
If the compilation is successful, .class files (e.g., CarRentalSystem.class, Car.class, Customer.class, etc.) will be created in the same directory.
Run the Application:

From the same terminal or command prompt, execute the compiled application using the java command:
Bash

java CarRentalSystem
The Car Rental System GUI application will then launch.
Usage Guide
The application's main window is designed for straightforward interaction:

Top Bar: Displays the "Car Rental System" title.
Left Panel (Available Cars): This section lists all cars in your fleet, showing their current availability status. You can select a car from this list to initiate a rental.
Right Panel (Rental History): This panel is dedicated to displaying and managing all rental transactions.
Search Bar: Use this to filter the rental list by typing in a Car ID, Customer Name, or Phone Number.
Filter Dropdown: Filter rentals by their status (Active, Returned) or by rental date range (Last 7 Days, Last 30 Days).
Statistics Bar: Located at the bottom of the right panel, it provides real-time statistics on your car inventory and rental activity.
Action Buttons (Bottom Panel):
Rent Car: Click this to begin the car rental process.
Return Car: Use this to mark a car as returned.
Add New Car: Opens a dialog to add details for a new car to the system.
Performing Actions:
Rent a Car:

Select an available car from the "Available Cars" list on the left.
Click the Rent Car button.
A dialog will appear prompting for Customer Name, Phone Number, and Number of Days for the rental.
Enter the required details and click "OK".
A rental receipt will be displayed, the car's status will update, and the new rental will be added to the "Rental History."
Return a Car:

Select an active rental from the "Rental History" list on the right.
Click the Return Car button.
Confirm the return when prompted.
The rental's status will change to "Returned," and the associated car will become "Available" again.
Add a New Car:

Click the Add New Car button.
A dialog will appear asking for Car ID, Brand, Model, and Base Price per Day.
Enter the car's details and click "OK".
The newly added car will now be visible in the "Available Cars" list.
Code Structure
The system's code is organized into several key classes:

Car: Defines the attributes and behavior of a car, including its ID, brand, model, daily rental price, and availability status.
Customer: Represents a customer, storing their ID, name, phone number, and maintaining a list of their past rentals.
Rental: Encapsulates a single rental transaction. It links a Car and Customer and includes details like rental duration, rental/return dates, total price, and whether the rental has been returned.
CarRentalSystem: This is the main class responsible for setting up the Java Swing GUI. It contains all the core business logic for managing cars, customers, and rentals, including methods for renting, returning, adding cars, and updating the UI with data filtering and statistics.
CarListRenderer & RentalListRenderer: These custom ListCellRenderer implementations control how Car and Rental objects are visually displayed within the JList components, providing formatted text and visual cues (like color-coding for rental status).
Visual Design & Enhancements
Modern Color Scheme: The application utilizes a set of predefined PRIMARY_COLOR, SECONDARY_COLOR, BACKGROUND_COLOR, etc., to create a consistent and appealing visual design.
Clear Typography: "Arial" font is used throughout the interface to enhance readability.
Structured Layout: EmptyBorder and LineBorder are used to add visual separation and ensure a clean, organized layout.
Indian Rupee Currency: All monetary values are formatted to display in Indian Rupees (₹) for local relevance.
Dynamic UI Updates: The rental history and statistics panels update in real-time as you perform actions or apply filters.
Interactive Buttons: Buttons include subtle visual feedback (darkening on hover) to improve user interaction.