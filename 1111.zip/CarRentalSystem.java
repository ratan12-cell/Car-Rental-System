import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.text.NumberFormat;
import java.util.Locale;

class Car {
    private String carId;
    private String brand;
    private String model;
    private double basePricePerDay;
    private boolean isAvailable;

    public Car(String carId, String brand, String model, double basePricePerDay) {
        this.carId = carId;
        this.brand = brand;
        this.model = model;
        this.basePricePerDay = basePricePerDay;
        this.isAvailable = true;
    }

    public String getCarId() { return carId; }
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public double calculatePrice(int days) { return basePricePerDay * days; }
    public boolean isAvailable() { return isAvailable; }
    public void rent() { isAvailable = false; }
    public void returnCar() { isAvailable = true; }

    public String toString() {
        return carId + " - " + brand + " " + model + (isAvailable ? " (Available)" : " (Rented)");
    }
}

class Customer {
    private String customerId;
    private String name;
    private String phoneNumber;
    private List<Rental> rentalHistory;

    public Customer(String customerId, String name, String phoneNumber) {
        this.customerId = customerId;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.rentalHistory = new ArrayList<>();
    }

    public String getCustomerId() { return customerId; }
    public String getName() { return name; }
    public String getPhoneNumber() { return phoneNumber; }
    public List<Rental> getRentalHistory() { return rentalHistory; }
    public void addRental(Rental rental) { rentalHistory.add(rental); }
}

class Rental {
    private Car car;
    private Customer customer;
    private int days;
    private LocalDateTime rentalDate;
    private LocalDateTime returnDate;
    private boolean isReturned;
    private double totalPrice;

    public Rental(Car car, Customer customer, int days) {
        this.car = car;
        this.customer = customer;
        this.days = days;
        this.rentalDate = LocalDateTime.now();
        this.isReturned = false;
        this.totalPrice = car.calculatePrice(days);
    }

    public Car getCar() { return car; }
    public Customer getCustomer() { return customer; }
    public int getDays() { return days; }
    public LocalDateTime getRentalDate() { return rentalDate; }
    public LocalDateTime getReturnDate() { return returnDate; }
    public boolean isReturned() { return isReturned; }
    public double getTotalPrice() { return totalPrice; }
    
    public void markAsReturned() { 
        this.isReturned = true;
        this.returnDate = LocalDateTime.now();
    }
}

public class CarRentalSystem {
    private JFrame frame;
    private DefaultListModel<Car> carListModel;
    private DefaultListModel<Rental> rentalListModel;
    private JList<Car> carJList;
    private JList<Rental> rentalJList;
    private final List<Car> cars;
    private final List<Customer> customers;
    private final List<Rental> rentals;
    private JTextField searchField;
    private JComboBox<String> filterComboBox;
    private JLabel statsLabel;
    
    private static final NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
    
    private static final Color PRIMARY_COLOR = new Color(41, 128, 185);
    private static final Color SECONDARY_COLOR = new Color(52, 152, 219);
    private static final Color BACKGROUND_COLOR = new Color(236, 240, 241);
    private static final Color TEXT_COLOR = new Color(44, 62, 80);
    private static final Color SUCCESS_COLOR = new Color(46, 204, 113);
    private static final Color WARNING_COLOR = new Color(231, 76, 60);

    public CarRentalSystem() {
        cars = new ArrayList<>();
        customers = new ArrayList<>();
        rentals = new ArrayList<>();

        cars.add(new Car("C001", "Toyota", "Camry", 5000.0));
        cars.add(new Car("C002", "Honda", "Accord", 6000.0));
        cars.add(new Car("C003", "Mahindra", "Thar", 12000.0));

        frame = new JFrame("Car Rental System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setLayout(new BorderLayout(10, 10));
        frame.getContentPane().setBackground(BACKGROUND_COLOR);

        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(PRIMARY_COLOR);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel titleLabel = new JLabel("Car Rental System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        frame.add(titlePanel, BorderLayout.NORTH);

        JPanel contentPanel = new JPanel(new BorderLayout(10, 0));
        contentPanel.setBackground(BACKGROUND_COLOR);

        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(BACKGROUND_COLOR);
        
        JLabel carListLabel = new JLabel("Available Cars", SwingConstants.CENTER);
        carListLabel.setFont(new Font("Arial", Font.BOLD, 16));
        carListLabel.setForeground(TEXT_COLOR);
        leftPanel.add(carListLabel, BorderLayout.NORTH);

        carListModel = new DefaultListModel<>();
        cars.forEach(carListModel::addElement);

        carJList = new JList<>(carListModel);
        carJList.setCellRenderer(new CarListRenderer());
        carJList.setBackground(Color.WHITE);
        carJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        carJList.setFont(new Font("Arial", Font.PLAIN, 14));
        
        JScrollPane carScrollPane = new JScrollPane(carJList);
        carScrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(10, 10, 10, 10),
            BorderFactory.createLineBorder(PRIMARY_COLOR, 2)
        ));
        leftPanel.add(carScrollPane, BorderLayout.CENTER);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(BACKGROUND_COLOR);

        JPanel rentalHeaderPanel = new JPanel(new BorderLayout());
        rentalHeaderPanel.setBackground(BACKGROUND_COLOR);
        
        JLabel rentalListLabel = new JLabel("Rental History", SwingConstants.CENTER);
        rentalListLabel.setFont(new Font("Arial", Font.BOLD, 16));
        rentalListLabel.setForeground(TEXT_COLOR);
        rentalHeaderPanel.add(rentalListLabel, BorderLayout.NORTH);

        JPanel searchFilterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchFilterPanel.setBackground(BACKGROUND_COLOR);
        
        searchField = new JTextField(15);
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filterRentals();
            }
        });
        
        String[] filterOptions = {"All", "Active", "Returned", "Last 7 Days", "Last 30 Days"};
        filterComboBox = new JComboBox<>(filterOptions);
        filterComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        filterComboBox.addActionListener(e -> filterRentals());
        
        searchFilterPanel.add(new JLabel("Search: "));
        searchFilterPanel.add(searchField);
        searchFilterPanel.add(new JLabel("Filter: "));
        searchFilterPanel.add(filterComboBox);
        
        rentalHeaderPanel.add(searchFilterPanel, BorderLayout.CENTER);
        rightPanel.add(rentalHeaderPanel, BorderLayout.NORTH);

        rentalListModel = new DefaultListModel<>();
        rentalJList = new JList<>(rentalListModel);
        rentalJList.setCellRenderer(new RentalListRenderer());
        rentalJList.setBackground(Color.WHITE);
        rentalJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        rentalJList.setFont(new Font("Arial", Font.PLAIN, 14));
        
        JScrollPane rentalScrollPane = new JScrollPane(rentalJList);
        rentalScrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(10, 10, 10, 10),
            BorderFactory.createLineBorder(PRIMARY_COLOR, 2)
        ));
        rightPanel.add(rentalScrollPane, BorderLayout.CENTER);

        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statsPanel.setBackground(BACKGROUND_COLOR);
        statsLabel = new JLabel();
        statsLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        statsLabel.setForeground(TEXT_COLOR);
        statsPanel.add(statsLabel);
        rightPanel.add(statsPanel, BorderLayout.SOUTH);

        contentPanel.add(leftPanel, BorderLayout.WEST);
        contentPanel.add(rightPanel, BorderLayout.CENTER);
        frame.add(contentPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        
        JButton rentButton = createStyledButton("Rent Car", SUCCESS_COLOR);
        JButton returnButton = createStyledButton("Return Car", WARNING_COLOR);
        JButton addCarButton = createStyledButton("Add New Car", SECONDARY_COLOR);

        rentButton.addActionListener(e -> rentCar());
        returnButton.addActionListener(e -> returnCar());
        addCarButton.addActionListener(e -> addNewCar());

        buttonPanel.add(rentButton);
        buttonPanel.add(returnButton);
        buttonPanel.add(addCarButton);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        updateStatistics();
        filterRentals(); // show filtered rental list initially (all)
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        return button;
    }

    private void rentCar() {
        Car selectedCar = carJList.getSelectedValue();
        if (selectedCar == null) {
            showMessage("Please select a car to rent.", "No Car Selected");
            return;
        }
        if (!selectedCar.isAvailable()) {
            showMessage("This car is already rented.", "Unavailable Car");
            return;
        }

        JTextField nameField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField daysField = new JTextField();

        Object[] message = {
            "Customer Name:", nameField,
            "Phone Number:", phoneField,
            "Number of Days:", daysField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Enter Rental Details", JOptionPane.OK_CANCEL_OPTION);
        if (option != JOptionPane.OK_OPTION) {
            return;
        }

        String customerName = nameField.getText().trim();
        String phoneNumber = phoneField.getText().trim();
        String daysText = daysField.getText().trim();

        if (customerName.isEmpty() || phoneNumber.isEmpty() || daysText.isEmpty()) {
            showMessage("All fields are required.", "Missing Information");
            return;
        }

        int days;
        try {
            days = Integer.parseInt(daysText);
            if (days <= 0) {
                showMessage("Number of days must be positive.", "Invalid Input");
                return;
            }
        } catch (NumberFormatException ex) {
            showMessage("Please enter a valid number of days.", "Invalid Input");
            return;
        }

        // Check if customer with same phone exists
        Customer customer = customers.stream()
                .filter(c -> c.getPhoneNumber().equals(phoneNumber))
                .findFirst()
                .orElse(null);

        if (customer == null) {
            String customerId = "CU" + (customers.size() + 1);
            customer = new Customer(customerId, customerName, phoneNumber);
            customers.add(customer);
        }

        Rental rental = new Rental(selectedCar, customer, days);
        rentals.add(rental);
        customer.addRental(rental);
        selectedCar.rent();

        // Refresh UI
        refreshCarList();
        filterRentals();

        // Show rental receipt
        showRentalReceipt(rental);

        updateStatistics();
    }

    private void returnCar() {
        Rental selectedRental = rentalJList.getSelectedValue();
        if (selectedRental == null) {
            showMessage("Please select a rental to return.", "No Rental Selected");
            return;
        }
        if (selectedRental.isReturned()) {
            showMessage("This rental is already returned.", "Already Returned");
            return;
        }

        int option = JOptionPane.showConfirmDialog(frame,
                "Are you sure you want to return this car?",
                "Confirm Return",
                JOptionPane.YES_NO_OPTION);
        if (option != JOptionPane.YES_OPTION) return;

        selectedRental.markAsReturned();
        selectedRental.getCar().returnCar();

        refreshCarList();
        filterRentals();
        updateStatistics();

        showMessage("Car returned successfully!", "Return Successful");
    }

    private void addNewCar() {
        JTextField carIdField = new JTextField();
        JTextField brandField = new JTextField();
        JTextField modelField = new JTextField();
        JTextField priceField = new JTextField();

        Object[] message = {
            "Car ID:", carIdField,
            "Brand:", brandField,
            "Model:", modelField,
            "Base Price per Day (₹):", priceField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Add New Car", JOptionPane.OK_CANCEL_OPTION);
        if (option != JOptionPane.OK_OPTION) {
            return;
        }

        String carId = carIdField.getText().trim();
        String brand = brandField.getText().trim();
        String model = modelField.getText().trim();
        String priceText = priceField.getText().trim();

        if (carId.isEmpty() || brand.isEmpty() || model.isEmpty() || priceText.isEmpty()) {
            showMessage("All fields are required.", "Missing Information");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
            if (price <= 0) {
                showMessage("Price must be positive.", "Invalid Input");
                return;
            }
        } catch (NumberFormatException ex) {
            showMessage("Please enter a valid price.", "Invalid Input");
            return;
        }

        // Check if car ID already exists
        boolean exists = cars.stream().anyMatch(c -> c.getCarId().equalsIgnoreCase(carId));
        if (exists) {
            showMessage("A car with this ID already exists.", "Duplicate Car ID");
            return;
        }

        Car newCar = new Car(carId, brand, model, price);
        cars.add(newCar);
        refreshCarList();
        showMessage("New car added successfully!", "Success");
    }

    private void refreshCarList() {
        carListModel.clear();
        cars.forEach(carListModel::addElement);
    }

    private void filterRentals() {
        rentalListModel.clear();
        String searchText = searchField.getText().trim().toLowerCase();
        String filterOption = (String) filterComboBox.getSelectedItem();

        LocalDateTime now = LocalDateTime.now();

        for (Rental rental : rentals) {
            boolean matchesSearch = searchText.isEmpty() || 
                rental.getCar().getCarId().toLowerCase().contains(searchText) ||
                rental.getCustomer().getName().toLowerCase().contains(searchText) ||
                rental.getCustomer().getPhoneNumber().toLowerCase().contains(searchText);

            boolean matchesFilter = true;
            switch (filterOption) {
                case "Active":
                    matchesFilter = !rental.isReturned();
                    break;
                case "Returned":
                    matchesFilter = rental.isReturned();
                    break;
                case "Last 7 Days":
                    matchesFilter = rental.getRentalDate().isAfter(now.minusDays(7));
                    break;
                case "Last 30 Days":
                    matchesFilter = rental.getRentalDate().isAfter(now.minusDays(30));
                    break;
                default: // "All"
                    matchesFilter = true;
            }

            if (matchesSearch && matchesFilter) {
                rentalListModel.addElement(rental);
            }
        }
    }

    private void updateStatistics() {
        long totalCars = cars.size();
        long rentedCars = cars.stream().filter(c -> !c.isAvailable()).count();
        long availableCars = totalCars - rentedCars;
        long activeRentals = rentals.stream().filter(r -> !r.isReturned()).count();
        long returnedRentals = rentals.stream().filter(Rental::isReturned).count();

        String statsText = String.format(
            "<html><b>Stats:</b> Total Cars: %d | Available: %d | Rented: %d | Active Rentals: %d | Returned Rentals: %d</html>",
            totalCars, availableCars, rentedCars, activeRentals, returnedRentals
        );
        statsLabel.setText(statsText);
    }

    private void showRentalReceipt(Rental rental) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String receipt = String.format(
            "----- Rental Receipt -----\n" +
            "Customer: %s\nPhone: %s\n\n" +
            "Car ID: %s\nBrand: %s\nModel: %s\n\n" +
            "Days Rented: %d\nTotal Price: %s\n\n" +
            "Rental Date: %s\n-------------------------",
            rental.getCustomer().getName(),
            rental.getCustomer().getPhoneNumber(),
            rental.getCar().getCarId(),
            rental.getCar().getBrand(),
            rental.getCar().getModel(),
            rental.getDays(),
            currencyFormatter.format(rental.getTotalPrice()),
            dtf.format(rental.getRentalDate())
        );
        JOptionPane.showMessageDialog(frame, receipt, "Rental Receipt", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showMessage(String message, String title) {
        JOptionPane.showMessageDialog(frame, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    class CarListRenderer extends JLabel implements ListCellRenderer<Car> {
        public CarListRenderer() {
            setOpaque(true);
            setBorder(new EmptyBorder(5, 5, 5, 5));
            setFont(new Font("Arial", Font.PLAIN, 14));
        }
        @Override
        public Component getListCellRendererComponent(JList<? extends Car> list, Car value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            setText(value.toString());
            if (isSelected) {
                setBackground(PRIMARY_COLOR);
                setForeground(Color.WHITE);
            } else {
                setBackground(Color.WHITE);
                setForeground(TEXT_COLOR);
            }
            return this;
        }
    }

    class RentalListRenderer extends JLabel implements ListCellRenderer<Rental> {
        public RentalListRenderer() {
            setOpaque(true);
            setBorder(new EmptyBorder(5, 5, 5, 5));
            setFont(new Font("Arial", Font.PLAIN, 14));
        }
        @Override
        public Component getListCellRendererComponent(JList<? extends Rental> list, Rental value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            String returnDateText = value.isReturned() && value.getReturnDate() != null ? 
                dtf.format(value.getReturnDate()) : "Not returned";
            
            String text = String.format("%s rented by %s for %d day(s) | Status: %s | Rented on: %s | Returned: %s",
                    value.getCar().getCarId(),
                    value.getCustomer().getName(),
                    value.getDays(),
                    value.isReturned() ? "Returned" : "Active",
                    dtf.format(value.getRentalDate()),
                    returnDateText);

            setText(text);

            if (isSelected) {
                setBackground(SECONDARY_COLOR);
                setForeground(Color.WHITE);
            } else if (value.isReturned()) {
                setBackground(BACKGROUND_COLOR);
                setForeground(new Color(34, 139, 34)); // Dark green for returned
            } else {
                setBackground(BACKGROUND_COLOR);
                setForeground(TEXT_COLOR);
            }
            return this;
        }
    }

    public static void main(String[] args) {
        // Use SwingUtilities to start GUI thread safely
        SwingUtilities.invokeLater(CarRentalSystem::new);
    }
}